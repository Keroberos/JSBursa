window.addEventListener('load', function () {
  //Ваш код будет здесь
});